# __init__.py

__all__ = ["Variable", "InterfazGrafica"]

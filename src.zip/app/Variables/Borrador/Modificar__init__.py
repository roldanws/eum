# __init__.py
from .Variable import Variable
from .InterfazGrafica import InterfazGrafica


__all__ = ["Variable", "InterfazGrafica"]

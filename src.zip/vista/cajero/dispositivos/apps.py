from django.apps import AppConfig


class DispositivosConfig(AppConfig):
    name = 'dispositivos'

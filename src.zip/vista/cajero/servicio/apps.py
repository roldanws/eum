from django.apps import AppConfig


class ServicioConfig(AppConfig):
    name = 'servicio'
    verbose_name = 'Gestor de servicios'
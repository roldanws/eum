from django.urls import path
from .views import UiPageView,UiCancelacionView


ui_patterns = ([
    path('', UiPageView.as_view(), name='ui'),
    path('cancelacion/', UiCancelacionView.as_view(), name='cancelacion'),
],"ui")

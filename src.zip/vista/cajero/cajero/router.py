from api.viewsets import *
from rest_framework import routers

router = routers.DefaultRouter()
router.register('controladora',ControladoraViewset)
router.register('sensor',SensorViewset)
router.register('dispositivo',DispositivoViewset)
router.register('equipo',EquipoViewset)
router.register('impresora',ImpresoraViewset)
router.register('tarifa',TarifaViewset)
router.register('recurso',RecursoViewset)
router.register('servidor',ServidorViewset)
router.register('transaccion',TransaccionViewset)
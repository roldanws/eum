from django.apps import AppConfig


class ControladoraConfig(AppConfig):
    name = 'controladora'

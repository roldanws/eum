from django.apps import AppConfig


class TransaccionConfig(AppConfig):
    name = 'transaccion'

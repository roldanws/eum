from django.db import models
from django.utils.timezone import now
from equipo.models import Equipo
# Create your models here.

class Transaccion(models.Model):
    MODO = (
        ("EN RED", "EN RED"),
        ("EN LOCAL", "EN LOCAL"),
        ("STAND ALONE", "STAND ALONE"),
    )
    TIPO = (
        ("Expedidor", "Expedidor"),
        ("Validador", "Validador"),
        ("Cajero", "Cajero"),
        ("Punto de cobro", "Punto de cobro"),
        ("Servidor", "Servidor"),
    )

    folio_boleto = models.IntegerField(verbose_name='Folio boleto')
    expedidor_boleto = models.IntegerField(verbose_name='Expedidor boleto')
    fecha_expedicion_boleto = models.DateTimeField(verbose_name = 'Fecha de expedicion boleto', default = now)
    codigo = models.IntegerField(verbose_name='Codigo')
    registrado = models.BooleanField(verbose_name = 'Registrado')
    monto = models.IntegerField(verbose_name='Monto')
    cambio = models.IntegerField(verbose_name='Cambio')
    monedas = models.CharField(max_length=200, verbose_name = 'Monedas')
    billetes = models.CharField(max_length=200, verbose_name = 'Billetes')
    cambio_entregado = models.CharField(max_length=200, verbose_name = 'Cambio entregado')
    created = models.DateTimeField(verbose_name = 'Fecha transaccion', default = now)
    updated = models.DateTimeField(auto_now=True, verbose_name = 'Ultima modificacion')
    equipo_id = models.ForeignKey(Equipo, verbose_name = 'Equipos', related_name='get_transaccion', on_delete = models.CASCADE)

    class Meta:
        verbose_name = 'Transaccion'
        verbose_name_plural = 'Transaccion'
        ordering = ['-created']

    def __str__(self):
        return str(self.created) + " " + str(self.monto) + " " + str(self.codigo) 
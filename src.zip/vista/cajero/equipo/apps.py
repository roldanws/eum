from django.apps import AppConfig


class EquipoConfig(AppConfig):
    name = 'equipo'

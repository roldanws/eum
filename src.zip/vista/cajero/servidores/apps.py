from django.apps import AppConfig


class ServidoresConfig(AppConfig):
    name = 'servidores'

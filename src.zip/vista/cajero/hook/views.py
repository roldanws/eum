from django.shortcuts import render
import json
from django.http import HttpResponse
from django.views.generic import View
from braces.views import CsrfExemptMixin
from django.views.decorators.csrf import csrf_exempt

from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

from chat_app import consumers
from ui.views import UiPageView,UiCancelacionView
class Respuestas:
    def __init__(self):
        self.respuestas = dict (
        cancelar_pago = 0,
        )
    def obtener_respuestas(self):
        return self.respuestas
    def establecer_respuestas(self,llave,valor):
        self.respuestas[llave] = valor

class ProcessHookView(CsrfExemptMixin, View, Respuestas):
    
    respuestas = Respuestas()
    #@method_decorator(csrf_exempt)
    def post(self, request, *args, **kwargs):
        #print("cicle")
        #print( request.body))
        conv = request.body.decode('utf-8').replace('\0', '')
        #print(json.loads(conv))
        message = json.loads(conv)
        #message = "{'nombre': 'rodrigo', 'mensaje': 'que hubo'}"
        message = str(message).replace("'",'"')
        #print("NANI?:",message)
        #message = '{"nombre":"r","mensaje":"xyz"}'
        #consumers.ws_add(message)
        consumers.ws_message(message)

        
        print(self.respuestas.obtener_respuestas(),"#################")
        '''string = request.read().decode('utf-8')
        json_obj = json.loads(string)
        print(string) # prints the string with 'source_name' key'''
        #print(json.loads(request.read().decode(request.body)))
        
        '''
        if 'json' in request.headers.get('Content-Type'):
            js =request.json()
        else:
            print('Response content is not in JSON format.',request.headers.get('Content-Type'))
            js = 'spam'
        '''
        print("CANCELAR_PAGO:",type(message))
        if '"cancelar_pago": 2' in message:
            self.respuestas.establecer_respuestas("cancelar_pago",0)
        if '"cancelar_pago": 1' in message:
            self.respuestas.establecer_respuestas("cancelar_pago",1)
        #if '"cancelar_pago": 0' in message:
        #    self.respuestas.establecer_respuestas("cancelar_pago",0)

        if '"peticion_cancelacion": 1' in message:
            self.respuestas.establecer_respuestas("cancelar_pago",1)

        if self.respuestas.obtener_respuestas()["cancelar_pago"]:
            return HttpResponse('{"cancelar_pago":"1"}', content_type='application/json')
        else:
            return HttpResponse('{"cancelar_pago":"0"}', content_type='application/json')
        

# Create your views here.

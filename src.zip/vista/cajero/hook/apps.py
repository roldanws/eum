from django.apps import AppConfig


class HookConfig(AppConfig):
    name = 'hook'

from django.apps import AppConfig


class AlertasConfig(AppConfig):
    name = 'alertas'

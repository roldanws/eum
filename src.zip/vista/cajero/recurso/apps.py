from django.apps import AppConfig


class RecursoConfig(AppConfig):
    name = 'recurso'
